// Two-road traffic-light controller using a MOD-N timing counter.
// Sequence: NS green -> NS yellow -> EW green -> EW yellow -> repeat.
module traffic_light_controller #(
    parameter integer GREEN_TICKS  = 10,
    parameter integer YELLOW_TICKS = 3,
    parameter integer COUNT_WIDTH  = 16
)(
    input  wire clk,
    input  wire reset,
    output reg ns_red,
    output reg ns_yellow,
    output reg ns_green,
    output reg ew_red,
    output reg ew_yellow,
    output reg ew_green
);
    localparam [1:0] NS_GO  = 2'd0;
    localparam [1:0] NS_WARN= 2'd1;
    localparam [1:0] EW_GO  = 2'd2;
    localparam [1:0] EW_WARN= 2'd3;

    reg [1:0] state;
    reg [COUNT_WIDTH-1:0] phase_count;
    reg [COUNT_WIDTH-1:0] phase_limit;

    always @(*) begin
        case (state)
            NS_GO, EW_GO: phase_limit = GREEN_TICKS - 1;
            default:      phase_limit = YELLOW_TICKS - 1;
        endcase
    end

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state       <= NS_GO;
            phase_count <= 0;
        end else begin
            if (phase_count >= phase_limit) begin
                phase_count <= 0;
                case (state)
                    NS_GO:   state <= NS_WARN;
                    NS_WARN: state <= EW_GO;
                    EW_GO:   state <= EW_WARN;
                    default: state <= NS_GO;
                endcase
            end else begin
                phase_count <= phase_count + 1'b1;
            end
        end
    end

    always @(*) begin
        ns_red    = 1'b0; ns_yellow = 1'b0; ns_green = 1'b0;
        ew_red    = 1'b0; ew_yellow = 1'b0; ew_green = 1'b0;
        case (state)
            NS_GO:   begin ns_green = 1'b1; ew_red = 1'b1; end
            NS_WARN: begin ns_yellow= 1'b1; ew_red = 1'b1; end
            EW_GO:   begin ew_green = 1'b1; ns_red = 1'b1; end
            EW_WARN: begin ew_yellow= 1'b1; ns_red = 1'b1; end
            default: begin ns_red = 1'b1; ew_red = 1'b1; end
        endcase
    end
endmodule
