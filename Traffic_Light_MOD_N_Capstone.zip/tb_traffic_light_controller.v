`timescale 1ns/1ps
module tb_traffic_light_controller;
    reg clk = 0;
    reg reset = 1;
    wire ns_red, ns_yellow, ns_green;
    wire ew_red, ew_yellow, ew_green;

    // Short timings make simulation quick.
    traffic_light_controller #(
        .GREEN_TICKS(5),
        .YELLOW_TICKS(2)
    ) dut (
        .clk(clk), .reset(reset),
        .ns_red(ns_red), .ns_yellow(ns_yellow), .ns_green(ns_green),
        .ew_red(ew_red), .ew_yellow(ew_yellow), .ew_green(ew_green)
    );

    always #5 clk = ~clk;

    initial begin
        $dumpfile("traffic_light.vcd");
        $dumpvars(0, tb_traffic_light_controller);
        #12 reset = 0;
        #180;
        $finish;
    end

    initial begin
        $monitor("time=%0t NS(RYG)=%b%b%b EW(RYG)=%b%b%b",
                 $time, ns_red, ns_yellow, ns_green,
                 ew_red, ew_yellow, ew_green);
    end
endmodule
