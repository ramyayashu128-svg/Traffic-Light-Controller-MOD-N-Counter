// Parameterized MOD-N counter
module mod_n_counter #(
    parameter integer N = 10,
    parameter integer WIDTH = (N <= 2) ? 1 : $clog2(N)
)(
    input  wire clk,
    input  wire reset,
    input  wire enable,
    output reg  [WIDTH-1:0] count,
    output reg  tick
);
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            count <= 0;
            tick  <= 1'b0;
        end else begin
            tick <= 1'b0;
            if (enable) begin
                if (count == N-1) begin
                    count <= 0;
                    tick  <= 1'b1;
                end else begin
                    count <= count + 1'b1;
                end
            end
        end
    end
endmodule
